using System.Diagnostics;
using System.Windows.Forms;
using System.Drawing;

namespace process
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

            timer1.Interval = 10000;
            timer1.Enabled = true;
            timer1.Tick += new System.EventHandler(timer1_Tick);
        }

        /// <summary>
        /// /*Form1_Load loads all secondary functions */
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {

            textBox1_TextChanged(sender, e);
            listView1_SelectedIndexChanged(sender, e);
        }
        /// <summary>
        /// The button responsible for canceling the task
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {

            Process[] processes = Process.GetProcesses();
            //processes[].Kill();

        }

        /// <summary>
        /// The function responsible for outputting the list of processes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        /// <summary>
        /// Timer responsible for updating the list of processes 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {

            listView1.Items.Clear();
            listView1_SelectedIndexChanged(sender, e);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// The function starts an additional window for starting tasks
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void �������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (Form2 from = new Form2())
            {
                if (from.ShowDialog() == DialogResult.OK)
                {

                }


            }

        }
        /// <summary>
        /// The function closes the dispatcher
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void �����ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        /// <summary>
        /// This function was to delete the process that would be entered in the string
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {


            foreach (Process process in Process.GetProcesses())
            {
                imageList1 = new ImageList ();

                listView1.Items.Add(process.ProcessName);
                try
                {
                    // ��������� ������ ��������
                    Icon icon = Icon.ExtractAssociatedIcon(process.MainModule.FileName);

                    // ������� ����� PictureBox ��� ����������� ������
                    PictureBox pictureBox = new PictureBox();
                    pictureBox.Image = icon.ToBitmap();
                    pictureBox.SizeMode = PictureBoxSizeMode.AutoSize;

                    // ������������� ��������� PictureBox �� �����
                    pictureBox.Left = 10;
                    pictureBox.Top = pictureBox1.Controls.Count * 10;

                    // ��������� PictureBox �� �����
                    pictureBox1.Controls.Add(pictureBox);
                }
                catch
                {

                };

            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void getImage(object sender,EventArgs e)
        {
            listView1_SelectedIndexChanged(sender, e);
            pictureBox1_Click (sender, e);  
        }
    }
}

