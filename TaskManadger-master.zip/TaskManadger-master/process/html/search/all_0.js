var searchData=
[
  ['button1_0',['button1',['../classprocess_1_1_form1.html#a78dc5d579d51a8cd54a59bd5cbb7ef21',1,'process.Form1.button1'],['../classprocess_1_1_form2.html#a00de0301a298e0bba617d5fb78daa80d',1,'process.Form2.button1']]],
  ['button1_5fclick_1',['button1_Click',['../classprocess_1_1_form1.html#a080740ee11a6b2e0991abbaa599ccff7',1,'process.Form1.button1_Click()'],['../classprocess_1_1_form2.html#a1b57a990dcc89e6b28baea089a5f3e41',1,'process.Form2.button1_Click()']]],
  ['button2_2',['button2',['../classprocess_1_1_form1.html#a6db604d8b5ba559c4f723aae4237ed2c',1,'process.Form1.button2'],['../classprocess_1_1_form2.html#a949eb412f3590a3723d0ae278e3b8c3e',1,'process.Form2.button2']]],
  ['button2_5fclick_3',['button2_Click',['../classprocess_1_1_form1.html#ad592557aec43eefc84b232a0ce3b83be',1,'process.Form1.button2_Click()'],['../classprocess_1_1_form2.html#a9eb3e9f6710fc81381fc8b13ab0d6e63',1,'process.Form2.button2_Click()']]]
];
