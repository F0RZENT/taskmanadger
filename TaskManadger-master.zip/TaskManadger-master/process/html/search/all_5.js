var searchData=
[
  ['label1_0',['label1',['../classprocess_1_1_form2.html#a12d72cc4034856b10629898905750f5e',1,'process::Form2']]],
  ['label1_5fclick_1',['label1_Click',['../classprocess_1_1_form2.html#abd45fc061a204975bc98f8c7c7818774',1,'process::Form2']]],
  ['listbox1_2',['listBox1',['../classprocess_1_1_form1.html#ac1a81aed3101efcde06ee0a3010c9de5',1,'process::Form1']]],
  ['listbox1_5fselectedindexchanged_5f1_3',['listBox1_SelectedIndexChanged_1',['../classprocess_1_1_form1.html#a4eddde70df634ef074aab7d813011ff2',1,'process::Form1']]]
];
