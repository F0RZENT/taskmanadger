var searchData=
[
  ['menustrip1_0',['menuStrip1',['../classprocess_1_1_form1.html#a0dcea67c5665371bb52828775a27b549',1,'process::Form1']]]
];
