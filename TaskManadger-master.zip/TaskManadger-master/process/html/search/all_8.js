var searchData=
[
  ['textbox1_0',['textBox1',['../classprocess_1_1_form1.html#a388c3bfad11bdfd13f4404dcbd4f785f',1,'process.Form1.textBox1'],['../classprocess_1_1_form2.html#a159abdbfda75eb26d1eba4d0ad1f76f5',1,'process.Form2.textBox1']]],
  ['textbox1_5ftextchanged_1',['textBox1_TextChanged',['../classprocess_1_1_form1.html#a30893a86fbaf677768bb8de1737fe586',1,'process.Form1.textBox1_TextChanged()'],['../classprocess_1_1_form2.html#a3ed929c3695f137ee66fbc6990179a94',1,'process.Form2.textBox1_TextChanged()']]],
  ['timer1_2',['timer1',['../classprocess_1_1_form1.html#a828b1b497ff9f83bc2f525537b11bd2a',1,'process::Form1']]],
  ['timer1_5ftick_3',['timer1_Tick',['../classprocess_1_1_form1.html#a8b57b49439855edbd6b3915edfba1df6',1,'process::Form1']]],
  ['toolstripmenuitem1_4',['toolStripMenuItem1',['../classprocess_1_1_form1.html#af0129ef9e78b038b72d3e4bfef4e21cc',1,'process::Form1']]]
];
