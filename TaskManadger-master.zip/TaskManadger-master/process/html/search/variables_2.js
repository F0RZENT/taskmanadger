var searchData=
[
  ['label1_0',['label1',['../classprocess_1_1_form2.html#a12d72cc4034856b10629898905750f5e',1,'process::Form2']]],
  ['listbox1_1',['listBox1',['../classprocess_1_1_form1.html#ac1a81aed3101efcde06ee0a3010c9de5',1,'process::Form1']]]
];
