var searchData=
[
  ['textbox1_0',['textBox1',['../classprocess_1_1_form1.html#a388c3bfad11bdfd13f4404dcbd4f785f',1,'process.Form1.textBox1'],['../classprocess_1_1_form2.html#a159abdbfda75eb26d1eba4d0ad1f76f5',1,'process.Form2.textBox1']]],
  ['timer1_1',['timer1',['../classprocess_1_1_form1.html#a828b1b497ff9f83bc2f525537b11bd2a',1,'process::Form1']]],
  ['toolstripmenuitem1_2',['toolStripMenuItem1',['../classprocess_1_1_form1.html#af0129ef9e78b038b72d3e4bfef4e21cc',1,'process::Form1']]]
];
